<?php
namespace Kharvi\Tfa\Observer;
    use Magento\Framework\Event\ObserverInterface;

    class Tfacheck implements ObserverInterface{
        protected $_objectManager;
        protected $authHelper;
        protected $adminSession;
        protected $authSession;
        protected $_logger;
        protected $registry;
        protected $_request;

        public function __construct(
            \Magento\Framework\ObjectManagerInterface $objectManager,
            \Kharvi\Tfa\Helper\Auth $authHelper,
            \Magento\Backend\Model\Auth\Session $authSession,
            \Psr\Log\LoggerInterface $logger,
            \Magento\Framework\Registry $registry,    
            \Magento\Backend\Model\Session $adminSession,
            \Magento\Framework\App\RequestInterface $request
        ) {
            $this->_objectManager = $objectManager;
            $this->authHelper = $authHelper;
            $this->adminSession = $adminSession;
            $this->authSession = $authSession;
            $this->_logger = $logger;
            $this->registry = $registry;
            $this->_request = $request;
        }

        public function execute(\Magento\Framework\Event\Observer $observer){
            $this->_logger->info('start the execute method');
            
            $requestInterface = $this->_objectManager->get('Magento\Framework\App\RequestInterface');
            $actionName     = $requestInterface->getActionName();
            $moduleName     = $requestInterface->getModuleName();
            $controllerName = $requestInterface->getControllerName();
            
            if($moduleName == 'tfa'){
                return;
            }
            
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $cookieManager = $objectManager->get('Magento\Framework\Stdlib\CookieManagerInterface');

            $isAdminPasswordExpired = $this->authSession->getPciAdminUserIsPasswordExpired();
            
            $this->_logger->info($isAdminPasswordExpired);
            $this->_logger->info($moduleName);
            $this->_logger->info($controllerName);
            $this->_logger->info($actionName); 
            
            
            $this->_logger->info('get cookie value');
            $rvalue = $cookieManager->getCookie('isPassReset');
            $this->_logger->info($rvalue);
            
            if(!empty($rvalue)){
                $this->_logger->info('in cookie value');
                $isAdminPasswordExpired = false;
                $this->_logger->info('isAdminPasswordExpired set false');               
                
                $cookieManager->deleteCookie('is_pass_reset');
                
            }
            
            if($isAdminPasswordExpired){
                if( ! $this->authSession->getUser()->getTwofactorToken()){
                   $this->_logger->info('in isAdminPasswordExpired if');
                 $this->adminSession->setTfaNotAssociated(true);  
                }else{                    
                     $this->adminSession->setTfaNotEntered(true);                 
                }
                //$this->adminSession->setpassrest(true);
                $this->_logger->info('set cookie value');
                $cookieManager->setPublicCookie('isPassReset', 'yes');
                return;
            }       
            
            $this->_logger->info($isAdminPasswordExpired);
            $this->_logger->info($this->adminSession->getTfaNotAssociated());
            
            if ($actionName == 'logout' || !$this->authHelper->isActive()) {
             return;
            }
            
            if ($moduleName == 'tfa') {                
                return;
            }
            
            $vRedirectUrl = '';
            //var_dump($this->adminSession->getTfaNotAssociated());
           // var_dump($this->adminSession->getTfaNotEntered());
            
            if ($this->adminSession->getTfaNotAssociated() && ! $isAdminPasswordExpired) {
                $this->_logger->info('in proper redirect condition');
                $vRedirectUrl = 'tfa/qr/qr';
            } else if ($this->adminSession->getTfaNotEntered() && ! $isAdminPasswordExpired) {    
                if (!$this->_request->isXmlHttpRequest()) {
                    $vRedirectUrl = 'tfa/interstitial/interstitial';
                }
            }
           
            $this->_logger->info($vRedirectUrl);
            
            if ($vRedirectUrl) {
             $observer->getControllerAction()->getResponse()->setRedirect($vRedirectUrl);
            } 
           // exit;
            return;        
               

        }
    }