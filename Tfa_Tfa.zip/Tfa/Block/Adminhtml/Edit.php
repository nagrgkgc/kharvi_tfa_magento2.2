<?php
namespace Kharvi\Tfa\Block\Adminhtml;

class Edit extends \Magento\Backend\Block\Widget\Form\Container
{
    
    protected $_coreRegistry = null;
    protected $authSession;
    protected $authHelper;
  
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        \Kharvi\Tfa\Helper\Auth $authHelper,
        \Magento\Backend\Model\Auth\Session $authSession,    
        array $data = []
    ) 
    {
        $this->_coreRegistry = $registry;
        $this->authHelper = $authHelper;
        $this->authSession = $authSession;
                parent::__construct($context, $data);
    }
 
    
    protected function _construct()
    {
        $this->_objectId = 'row_id';
        $this->_blockGroup = 'Kharvi_Tfa';
        $this->_controller = 'adminhtml';
        parent::_construct();
        
        $reAuthenticated = $this->authHelper->isReAuthenticated();
        $user = $this->authSession->getUser(); /** @var $user Mage_Admin_Model_User */
       /* if (Mage::getResourceModel('tfa/user_cookie')->hasCookies($user->getId()) && $reAuthenticated) {
            $this->addButton('clear_2fa_cookies', array(
                'label'     => Mage::helper('tfa')->__('Force security code on next login'),
                'onclick'   => 'confirmSetLocation(\''
                    . Mage::helper('tfa')->__('Are you sure you want to force security code on next login?')
                    . '\', \'' . $this->getUrl('adminhtml/tfa/clearCookies') . '\')'
            ));
        } */
        //var_dump($reAuthenticated); exit;
        if ($reAuthenticated) {
            
            //$this->buttonList->update('save', 'label', __('Reset authentication completely'));
            $this->buttonList->remove('save', 'label', __('Save'));         
            
            
            $this->addButton(
            'rest_to_default',
            [
                'label' => __('Reset authentication completely'),
                'onclick' => 'deleteConfirm(' . json_encode(__('Are you sure you want to reset authentication completely?'))
                    . ','
                    . json_encode($this->getResetToDefaultUrl())
                    . ')',
                'class' => 'scalable resrt_default',
                'level' => -1
            ]
          );           
           
        }
        if ( ! $reAuthenticated) {
           // $this->updateButton('save', 'label', $this->__('Submit Password'));
            $this->buttonList->update('save', 'label', __('Submit'));
        }
       
           
      
    }
 
    
    public function getHeaderText()
    {
        return __('Authentication');
    }
 
   
 
    public function getFormActionUrl()
    {
        if ($this->hasFormActionUrl()) {
            return $this->getData('form_action_url');
        }
 
        return $this->getUrl('*/*/save');
    }
    
    
    /**
     * @param array $args
     * @return string
     */
    public function getResetToDefaultUrl()
    {        
        return $this->getUrl('tfa/qr/reset');
    }

}