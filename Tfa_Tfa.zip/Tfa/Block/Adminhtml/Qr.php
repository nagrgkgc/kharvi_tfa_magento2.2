<?php
	namespace Kharvi\Tfa\Block\Adminhtml;
	
	use Magento\Backend\Block\Template;
	use Kharvi\Tfa\Helper\Auth;
	
	class Qr extends Template
	{
        /**
			* @param Context $context
			* @param array $data
		*/
		
		protected $authHelper;
		protected $authTest;
        public function __construct(
        Template\Context $context,
        Auth $authHelper,        
        array $data = []
		) {
			parent::__construct($context, $data);
			$this->authHelper = $authHelper;
		} 
		
		public function getRememberConfigValue()
		{
			return $this->_scopeConfig->getValue(
			'tfa/config/enable_remember_me',
			\Magento\Store\Model\ScopeInterface::SCOPE_STORE
			);
		}
		
		/**
			* Retrieve QR code url
			*
			* @return string
		*/
		
		public function getQrCodeUrl(){   
			
			$qrCodeUrl = $this->_backendSession->getQrCodeUrl();
			
			if ( ! $qrCodeUrl) { 
				
				$qrCodeUrl = $this->authHelper->getQrCodeImageUrl($this->authHelper->getStoreName(), $this->getQrCodeSecret());            
				$this->_backendSession->setQrCodeUrl($qrCodeUrl);
			}
			return $qrCodeUrl;
		}
		
		/**
			* Retrieve QR core secret
			*
			* @return string
		*/
		public function getQrCodeSecret()
		{
			$secret = $this->_backendSession->getSecret();
			if ( ! $secret) {
				$secret = $this->authHelper->createSecret();
				$this->_backendSession->setSecret($secret);
			}
			return $secret;
		}
		
		public function getPostActionUrl()
		{
			return $this->_urlBuilder->getUrl('tfa/qr/qrsubmit');
		}
		
		public function getStoreName()
		{
			return $this->authHelper->getStoreName();
		}
	}	