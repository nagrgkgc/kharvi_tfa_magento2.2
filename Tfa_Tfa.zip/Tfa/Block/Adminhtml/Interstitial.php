<?php
	namespace Kharvi\Tfa\Block\Adminhtml;
	
	use Magento\Backend\Block\Template;
	use Kharvi\Tfa\Helper\Auth;
	
	class Interstitial extends Template
	{
        /**
			* @param Context $context
			* @param array $data
		*/
		
		protected $authHelper;
		protected $authTest;

        public function __construct(
        Template\Context $context,
        Auth $authHelper,        
        array $data = []
		) {
			parent::__construct($context, $data);        
			$this->authHelper = $authHelper;
		} 
		
		public function getRememberConfigValue()
		{
			return $this->_scopeConfig->getValue(
			'tfa/config/enable_remember_me',
			\Magento\Store\Model\ScopeInterface::SCOPE_STORE
			);
		}
		
		public function getPostActionUrl()
		{
			return $this->_urlBuilder->getUrl('tfa/interstitial/verify');
		}
		
	}
