<?php
namespace Kharvi\Tfa\Block\Adminhtml\Edit;

class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    protected $authHelper;
    
     public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Kharvi\Tfa\Helper\Auth $authHelper,
        array $data = []
    ) 
    {
       
        parent::__construct($context, $registry, $formFactory, $data);
        $this->authHelper = $authHelper;
    }
 
    protected function _prepareForm()
    {
       $reAuthenticated = $this->authHelper->isReAuthenticated();
        $action = $reAuthenticated ? 'qrSubmit' : 'password';
       
        $form = $this->_formFactory->create(
            ['data' => [
                            'id' => 'edit_form', 
                            'enctype' => 'multipart/form-data', 
                            'action' =>$this->getUrl('*/*/'.$action, array('_current' => TRUE)), 
                            'method' => 'post'
                        ]
            ]
        );
        $form->setHtmlIdPrefix('passwordauth_');
        if(! $reAuthenticated)
        {    
           $fieldset = $form->addFieldset(
                    'base_fieldset',
                    ['legend' => __('Please enter the password'), 'class' => 'fieldset-wide']
                );

             $fieldset->addField(
                'password',
                'password',
                [
                    'name' => 'password',
                    'label' => __('Password'),
                    'id' => 'pass',
                    'title' => __('Password'),
                    'class' => 'required-entry',
                    'required' => true,

                ]
            );
        }     
         //$form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
        return parent::_prepareForm();
}
}