<?php
 
namespace Kharvi\Tfa\Setup;
 
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
 
class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
 
        // create table 'admin_user_cookie'
        
        $tableName = $installer->getTable('admin_user_cookie');
        // Check if the table already exists
        if ($installer->getConnection()->isTableExists($tableName) != true) {
            // Create tutorial_simplenews table
            $table = $installer->getConnection()
                ->newTable($tableName)
                ->addColumn(
                    'cookie_id',
                    Table::TYPE_INTEGER,                        
                    10,
                    [
                        'identity' => true,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                    ],
                    'Cookie Id'
                )
                ->addColumn(
                    'user_id',
                    Table::TYPE_INTEGER,
                    10,
                    ['nullable' => false, 'unsigned' => true],
                    'Admin User ID'
                )
                ->addColumn(
                    'cookie',
                    Table::TYPE_TEXT,
                    40,                    
                    ['nullable' => false, 'default' => ''],
                    'cookie'
                )
                ->addIndex(
                $installer->getIdxName(
                    $tableName,
                    ['user_id', 'cookie'],
                    \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE
                ),
                ['user_id', 'cookie'],
                ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE]
                )    
                ->addForeignKey(
                $installer->getFkName($tableName, 'user_id', 'admin_user','user_id'),
                'user_id',
                $installer->getTable('admin_user'), 
                'user_id',
                \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE                
                )     
                ->setComment('admin_user_cookie Table')
                ->setOption('type', 'InnoDB')
                ->setOption('charset', 'utf8');
            $installer->getConnection()->createTable($table);
        }
        
        
        // create table 'admin_user_question'
        
        $tableName = $installer->getTable('admin_user_question');
        // Check if the table already exists
        if ($installer->getConnection()->isTableExists($tableName) != true) {
            // Create tutorial_simplenews table
            $table = $installer->getConnection()
                ->newTable($tableName)
                ->addColumn(
                    'question_id',
                    Table::TYPE_INTEGER,
                    10,
                    [
                        'identity' => true,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                    ],
                    'Question ID'
                )
                ->addColumn(
                    'user_id',
                    Table::TYPE_INTEGER,
                    10,
                    ['nullable' => false, 'unsigned' => true],
                    'Admin User ID'
                )
                ->addColumn(
                    'question',
                    Table::TYPE_TEXT,
                    100,
                    ['nullable' => false, 'default' => ''],
                    'Question'
                )
                ->addColumn(
                    'answer',
                    Table::TYPE_TEXT,
                    255,
                    ['nullable' => false, 'default' => ''],
                    'answer'
                )
                ->addIndex(
                $installer->getIdxName(
                    $tableName,
                    ['user_id', 'question'],
                    \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE
                ),
                ['user_id', 'question'],
                ['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE]
                )    
                ->addForeignKey(
                $installer->getFkName($tableName, 'user_id', 'admin_user','user_id'),
                'user_id',
                $installer->getTable('admin_user'), 
                'user_id',
                \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE                
                )     
                ->setComment('admin_user_question Table')
                ->setOption('type', 'InnoDB')
                ->setOption('charset', 'utf8');
            $installer->getConnection()->createTable($table);
        }
        
        $adminUserTable = $installer->getTable('admin_user');
        $columns = [
            'twofactor_token' => [
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,                
                'comment' => 'Google Authenticator Token',
            ],

        ];

        $connection = $installer->getConnection();
        foreach ($columns as $name => $definition) {
            $connection->addColumn($adminUserTable, $name, $definition);
        }
 
        $installer->endSetup();
    }
}