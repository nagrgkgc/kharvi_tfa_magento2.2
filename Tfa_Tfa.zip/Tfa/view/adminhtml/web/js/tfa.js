require(['jquery', 'mage/translate'],
    function () {
        jQuery(document).on('click', '#whats-this', function () {
            jQuery('#what-is-this-qr').show();
            jQuery(this).hide()
        });
    }
);