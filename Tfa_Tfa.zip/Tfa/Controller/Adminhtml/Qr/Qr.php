<?php
    namespace Kharvi\Tfa\Controller\Adminhtml\Qr;
    use Magento\Backend\App\Action\Context;
    
    class Qr extends \Magento\Backend\App\Action{  
		
        protected $authSession;
        protected $authHelper;        
        protected $_resultPageFactory;
        
        public function __construct(
        Context $context,        
        \Magento\Backend\Model\Auth\Session $authSession,
        \Kharvi\Tfa\Helper\Auth $authHelper,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory        
        ) { 
			parent::__construct($context);
			$this->context = $context;
			$this->authSession = $authSession;
			$this->authHelper = $authHelper;
			$this->_resultPageFactory = $resultPageFactory;            
		}
        
        public function execute(){     
            
			if ($this->_hasToken() && $this->_isAuthenticated()) {
				$this->_redirect('*/*/edit');
				return;
			}
			$page = $this->_resultPageFactory->create();              
			return $page;           
		}
        
        /**
			* Check whether the user has authentication token
			*
			* @return bool
		*/
		protected function _hasToken()
		{
			$user = $this->authSession->getUser();
			if (!$user)
			{
				return false;
			}
			return !! $user->getTwofactorToken();
		}
		
		/**
			* Check whether the user is authenticated with 2FA
			*
			* @return bool
		*/
		protected function _isAuthenticated()
		{
			return ! $this->_session->getTfaNotEntered();
		}
		
		
	}
?>

