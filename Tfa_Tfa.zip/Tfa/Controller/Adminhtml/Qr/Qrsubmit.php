<?php
    namespace Kharvi\Tfa\Controller\Adminhtml\Qr;
    use Magento\Backend\App\Action\Context;  
    
    class Qrsubmit extends \Magento\Backend\App\Action{  
        
        protected $authSession;
        protected $authHelper;
        
        public function __construct(
        Context $context,        
        \Magento\Backend\Model\Auth\Session $authSession,
        \Kharvi\Tfa\Helper\Auth $authHelper
        ) { 
			parent::__construct($context);
			$this->context = $context;
			$this->authSession = $authSession;
			$this->authHelper = $authHelper;
		}
        
        public function execute(){
            
            $data = $this->getRequest()->getPostValue();            
            if (!$data) {                
                return;
			}
            
			// Process secret token if not yet configured
            
            if( ! $this->authSession->getUser()->getTwofactorToken()){                
                $secret = (string) $this->getRequest()->getPost('qr_secret');
				$securityCode = (string) $this->getRequest()->getPost('security_code');
				if ( ! $secret || ! $securityCode) {                  
					$this->_redirect('*/*/qr');
					return;
				}
				// Verify 2FA security code
				
				if ($this->authHelper->verifyCode($securityCode, $secret)) {
					try {
						$this->authSession->getUser()->setTwofactorToken($secret)->save();
						$this->_session->unsTfaNotAssociated();
						//$this->_redirect('tfa/qr/edit');
						//return;
					}
					catch (Exception $e) {                        
						$this->messageManager->addError(__('An error occurred while saving the security code.'));
						$this->_redirect('*/*/qr');
						return;
					}
					// Do not require 2-Factor-Authentication on this computer in the future
					/* $rememberMe = (bool) $this->getRequest()->getPost('remember_me', FALSE);
						if ($rememberMe) {
						try {
						$cookie = Mage::helper('tfa/auth')->generateCookie();
						Mage::getResourceModel('tfa/user_cookie')->saveCookie($this->_getUser()->getId(), $cookie);
						Mage::helper('tfa/auth')->setCookie($cookie);
						} catch (Exception $e) {
						Mage::logException($e);
						}
					} */
					} else {                  
					$this->messageManager->addError(__('Invalid security code.'));                   
					$this->_redirect('*/*/qr');
					return;
				}   
			}      
            
            $this->_redirect('*/*/qr');
            return;
            
		}
	}
?>

