<?php
    namespace Kharvi\Tfa\Controller\Adminhtml\Qr;
    use Magento\Backend\App\Action\Context; 
    
    class Password extends \Magento\Backend\App\Action{  
        
        protected $authSession;
        protected $authHelper;
        protected $_credentialStorage;
        
        public function __construct(
        Context $context,        
        \Magento\Backend\Model\Auth\Session $authSession,
        \Kharvi\Tfa\Helper\Auth $authHelper,
        \Magento\Backend\Model\Auth\Credential\StorageInterface $credentialStorage        
        ) { 
			parent::__construct($context);
			$this->context = $context;
			$this->authSession = $authSession;
			$this->authHelper = $authHelper;
			$this->_credentialStorage = $credentialStorage;
			
            
		}
        
        public function execute(){           
			$password = (string)$this->getRequest()->getParam('password');
			if (empty($password)) {                
				$this->messageManager->addError(__('Invalid request.'));
				$this->_redirect('*');
				return;
			}
			
			$username = $this->authSession->getUser()->getUsername();
			
			$validUser = $this->getCredentialStorage()->login($username, $password);
			
			if (empty($validUser->getId())) {                
				$this->messageManager->addError(__('Invalid password.'));
                } else {
				$this->messageManager->addSuccess(__('The password was successfully verified.'));
				$this->_session->setData('reauthenticated_2fa', TRUE);
			}
			$this->_redirect('*/*/edit');
			return; 
		}
		
		/**
			* Return credential storage object
			*
			* @return null|\Magento\Backend\Model\Auth\Credential\StorageInterface
			* @codeCoverageIgnore
		*/
		public function getCredentialStorage()
		{
			return $this->_credentialStorage;
		}
	}
?>

