<?php
    namespace Kharvi\Tfa\Controller\Adminhtml\Qr;
    use Magento\Backend\App\Action\Context;  
    
    class Reset extends \Magento\Backend\App\Action{  
        
        protected $authSession;
        protected $authHelper;
        
        public function __construct(
        Context $context,        
        \Magento\Backend\Model\Auth\Session $authSession,
        \Kharvi\Tfa\Helper\Auth $authHelper
        ) { 
			parent::__construct($context);
			$this->context = $context;
			$this->authSession = $authSession;
			$this->authHelper = $authHelper;
		}
        
        public function execute(){            
            if ( ! $this->authHelper->isReAuthenticated()) {
                $this->messageManager->addError(__('Access Denied. Please reauthenticate with your password.'));
                $this->_redirect('*/*/edit');
                return;
			}
            
            if ( ! $this->authSession->getUser()->getTwofactorToken()) {
                $this->messageManager->addError($this->__('Two-Factor Authentication is not configured so cannot be reset.'));
                $this->_redirect('*/*/edit');
                return;
			}
			
			
			try{
				$user = $this->authSession->getUser();
				if ( !empty($user->getId()) )
				{
					$user->setTwofactorToken(NULL)->save();
					$this->messageManager->addSuccess(__('Two-Factor Authentication has been reset.'));
					$this->_session->setData('reauthenticated_2fa', FALSE);
				}
				} catch (\Exception $e) {
                $this->messageManager->addError(__('An unexpected error occurred while resetting the Two-Factor Authentication.'));   
			}
			
			// Logout the user
            if ( empty($user->getId()) )
            {              
				$this->_session->destroy();              
			}
			$this->_redirect('admin/dashboard');
			return;
		}
	}
?>

