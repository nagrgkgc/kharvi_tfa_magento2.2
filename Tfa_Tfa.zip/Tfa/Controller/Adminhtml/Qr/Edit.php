<?php
    namespace Kharvi\Tfa\Controller\Adminhtml\Qr;
    
    class Edit extends \Magento\Backend\App\Action
    {  
          
        protected $_resultPageFactory;
         
        public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
        )
       {
      
        parent::__construct($context);
        $this->_resultPageFactory = $resultPageFactory;
         //$this->_auth = $context->getAuth();
        }
        public function execute()
        {  
        
            $page = $this->_resultPageFactory->create();  
            $title = __('Password authentication');
            $page->getConfig()->getTitle()->prepend($title);
            return $page;
        }
    }


