<?php
    namespace Kharvi\Tfa\Controller\Adminhtml\Qr;
    use Magento\Backend\App\Action\Context; 
    
    class Logout extends \Magento\Backend\App\Action{  
        
        protected $authSession;
        protected $authHelper;        
        protected $_credentialStorage;
        
        public function __construct(
        Context $context,        
        \Magento\Backend\Model\Auth\Session $authSession,
        \Kharvi\Tfa\Helper\Auth $authHelper,
        \Magento\Backend\Model\Auth\Credential\StorageInterface $credentialStorage        
        ) { 
			parent::__construct($context);
			$this->context = $context;
			$this->authSession = $authSession;
			$this->authHelper = $authHelper;                          
			$this->_credentialStorage = $credentialStorage;
			
            
		}
        
        public function execute(){           
			$this->_session->destroy();
			$this->_redirect('*');
			return; 
		}
	}
?>

