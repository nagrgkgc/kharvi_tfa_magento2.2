<?php
    namespace Kharvi\Tfa\Controller\Adminhtml\Interstitial;
    use Magento\Backend\App\Action\Context;
    
    class Verify extends \Magento\Backend\App\Action
    {  
          
         protected $authSession;
        protected $authHelper;      
        protected $_credentialStorage;
        
        public function __construct(
        Context $context,        
        \Magento\Backend\Model\Auth\Session $authSession,
        \Kharvi\Tfa\Helper\Auth $authHelper,
        \Magento\Backend\Model\Auth\Credential\StorageInterface $credentialStorage        
        ) { 
             parent::__construct($context);
             $this->context = $context;
             $this->authSession = $authSession;
             $this->authHelper = $authHelper;                          
             $this->_credentialStorage = $credentialStorage;
             
            
        }
        
        public function execute()
        {  
        
        //$oRequest = Mage::app()->getRequest();
        $vInputCode = $this->getRequest()->getParam('input_code');
       // $rememberMe = (bool) $oRequest->getPost('remember_me', FALSE);
        //$authHelper = Mage::helper('tfa/auth');
        $vSecret = $this->authSession->getUser()->getTwofactorToken();        
        if ( ! $vSecret) {
            // User is accessing protected route without configured TFA
            $this->_redirect('*/*/qr');
            return;
        }
        $bValid = $this->authHelper->verifyCode($vInputCode, $vSecret);
        if ($bValid === FALSE) {
            $this->messageManager->addError(__('Invalid security code.'));
            $this->_redirect('*/*/interstitial');
            return;
        }
       /* if ($rememberMe) {
            try {
                $cookie = $authHelper->generateCookie();
                Mage::getResourceModel('tfa/user_cookie')->saveCookie($this->_getUser()->getId(), $cookie);
                $authHelper->setCookie($cookie);
            } catch (Exception $e) {
                Mage::logException($e);
            }
        } */
        $this->_session->unsTfaNotEntered();
        $this->_redirect('admin/dashboard');
        return;
        }
    }
