<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Kharvi\Tfa\Controller\Adminhtml\Rewrite\Index;

class Index extends \Magento\Backend\Controller\Adminhtml\Dashboard
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;
	
	protected $authSession;
    protected $authHelper;
    protected $_credentialStorage;
	protected  $HelperBackend;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Backend\Model\Auth\Session $authSession,
        \Kharvi\Tfa\Helper\Auth $authHelper,
        \Magento\Backend\Model\Auth\Credential\StorageInterface $credentialStorage,
		\Magento\Backend\Helper\Data $HelperBackend
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
		$this->authSession = $authSession;
			$this->authHelper = $authHelper;
			$this->_credentialStorage = $credentialStorage;
			$this->HelperBackend = $HelperBackend;
    }

    /**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
		$adminUrlQrFromEditPage = 'interstitial';		
		if(strpos($this->_redirect->getRefererUrl(), $adminUrlQrFromEditPage) === false){			
				
			$bTfaRequired = FALSE;
			if ($this->authHelper->isForceForBackend()) {            
				$bTfaRequired = TRUE;
			}
			
			if ($bTfaRequired) {           
				if (! $this->authSession->getUser()->getTwofactorToken()) {
					$this->_session->setTfaNotAssociated(TRUE);
					$resultRedirect = $this->resultRedirectFactory->create();
					return $resultRedirect->setPath('tfa/qr/qr');
					} else {
					$resultRedirect = $this->resultRedirectFactory->create();
					$this->_session->setTfaNotEntered(TRUE);                
					return $resultRedirect->setPath('tfa/interstitial/interstitial');
				}            
			}
		}			
			
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Magento_Backend::dashboard');
        $resultPage->addBreadcrumb(__('Dashboard'), __('Dashboard'));
        $resultPage->getConfig()->getTitle()->prepend(__('Dashboard'));

        return $resultPage;
    }
}
