<?php
	/**
		* Copyright © 2016 Magento. All rights reserved.
		* See COPYING.txt for license details.
	*/
	namespace Kharvi\Tfa\Plugin;
	
	use Magento\Backend\App\Action\Context;
	use Magento\Framework\UrlInterface;
	class Save
	{
		protected $authSession;
		protected $authHelper;
		protected $_url;
        public function __construct(
        Context $context,     
        \Magento\Backend\Model\Auth\Session $authSession,
        \Kharvi\Tfa\Helper\Auth $authHelper,
		UrlInterface $url
        ) { 
			//parent::__construct($context);
			$this->context = $context;
			$this->authSession = $authSession;
			$this->authHelper = $authHelper;
			$this->_url = $url;            
		}
		
		
		
		/**
			* Saving edited user information
			*
			* @return \Magento\Backend\Model\View\Result\Redirect
			* @SuppressWarnings(PHPMD.CyclomaticComplexity)
		*/
		public function afterExecute(\Magento\Backend\Controller\Adminhtml\System\Account\Save $subject, $result)
		{  
			//echo 'in execute'; exit;
			$bTfaRequired = FALSE;
			if ($this->authHelper->isForceForBackend()) {            
				$bTfaRequired = TRUE;
			}
			
			if ($bTfaRequired) {           
				if (! $this->authSession->getUser()->getTwofactorToken()) {
					$this->_session->setTfaNotAssociated(TRUE);
					$redirectUrl = $this->_url->getUrl('tfa/qr/qr');
					return $this->resultRedirectFactory->create()->setPath($redirectUrl);                        
                    } else {                        
					$redirectUrl = $this->_url->getUrl('tfa/interstitial/interstitial');
					$this->_session->setTfaNotEntered(TRUE); 
					return $this->resultRedirectFactory->create()->setPath($redirectUrl);
				}            
			}
		}
	}
