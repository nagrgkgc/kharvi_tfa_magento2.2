<?php


        
namespace Kharvi\Tfa\Helper;


class Auth extends \Magento\Framework\App\Helper\AbstractHelper
{    
    const TWO_FACTOR_AUTH_COOKIE = '2fa';
    protected $authSession;
    public $_storeManager;
    protected $frontAuthSession;
    protected $scopeConfig;
    protected $googleAuth;
    public function __construct(\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Backend\Model\Session $adminSession,
        \Magento\Backend\Model\Auth\Session $authSession,
        \Magento\Customer\Model\Session $frontAuthSession,    
        \Magento\Store\Model\StoreManagerInterface $storeManager,    
        \Kharvi\Tfa\Lib\GoogleAuthenticator $googleAuth
    ) {        
        $this->scopeConfig = $scopeConfig;        
        $this->adminSession = $adminSession;
        $this->authSession = $authSession;
        $this->_storeManager=$storeManager;
        $this->frontAuthSession = $frontAuthSession;
        $this->googleAuth = $googleAuth;
    }
    
    public function isActive()
    {
       return $this->scopeConfig->getValue(
			'tfa/config/active',
			\Magento\Store\Model\ScopeInterface::SCOPE_STORE
		);
    }
    
    public function isForceForBackend()
    {       
        return $this->scopeConfig->getValue(
			'tfa/config/is_forced_for_backend',
			\Magento\Store\Model\ScopeInterface::SCOPE_STORE
		);
    }
    
    /**
     * @return GoogleAuthenticator
     */
    protected function _getAuth()
    {
        return $this->googleAuth;
    }
    /**
     * Create a new 2fa secret
     *
     * @return string
     */
    public function createSecret()
    {
        return $this->_getAuth()->createSecret();
    }
    /**
     * Calculate the code, with given secret and point in time
     *
     * @param string $secret
     * @param int|null $timeSlice
     * @return string
     */
    public function getCode($secret, $timeSlice = null)
    {
        return $this->_getAuth()->getCode($secret, $timeSlice);
    }
    /**
     * Get the image url to a new QR code
     *
     * @param string $name
     * @param string $secret
     * @return string
     */
    public function getQrCodeImageUrl($name, $secret)
    {
        return $this->_getAuth()->getQRCodeGoogleUrl($name, $secret);
    }
    /**
     * Verify a 2fa code
     *
     * @param int $code
     * @param string $secret
     * @return bool
     */
    public function verifyCode($code, $secret)
    {
        return $this->_getAuth()->verifyCode($secret, $code, 2); // 2 = 60 seconds
    }
    /**
     * Get the name to pass to thru Google's QR service
     *
     * @return string
     */
    public function getStoreName()
    {  
        
        /* if (Mage::app()->getStore()->isAdmin()) {
            $username = Mage::getSingleton('admin/session')->getUser()->getUsername();            
        } else {
            $username = Mage::getSingleton('customer/session')->getCustomer()->getName();
        } 
        $baseUrl = parse_url(Mage::app()->getStore()->getBaseUrl()); 		
        return $username.'@'.$baseUrl['host']; */
        
        /* check is admin in magento */
        
        
        if($this->getCurrentUser())
        {
            $username = $this->authSession->getUser()->getUsername();
        }
        else
        {           
            $username = $this->frontAuthSession->getCustomer()->getName();
        }
        
        $baseUrl = parse_url($this->_storeManager->getStore()->getBaseUrl());
        return $username.'@'.$baseUrl['host'];
        
    }
    
    public function getCurrentUser()
    {
        return $this->authSession->getUser();
    }
    /**
     * Check whether the admin user has valid 2FA cookie
     *
     * @param int|Mage_Admin_Model_User $userId
     * @return bool
     */
    /*public function isAuthorized($userId)
    {
        if ( ! Mage::app()->getStore()->isAdmin()) {
            return FALSE;
        }
        $cookie = (string)Mage::getSingleton('core/cookie')->get(self::TWO_FACTOR_AUTH_COOKIE);
        if ($cookie) {
            $cookies = explode(',', $cookie);
            $userCookies = Mage::getResourceModel('tfa/user_cookie')->getCookies($userId);
            return (count(array_intersect($cookies, $userCookies)) > 0);
        }
        return FALSE;
    } */
    /**
     * Generate 2FA cookie
     *
     * @return string
     */
   /* public function generateCookie()
    {
        return sha1(Mage::helper('core')->getRandomString(20), FALSE);
    } */
    /**
     * Set 2FA cookie
     *
     * @param string $cookie
     * @return void
     */
    /* public function setCookie($cookie)
    {
        $cookie = (string)$cookie;
        $_cookie = (string)Mage::getSingleton('core/cookie')->get(self::TWO_FACTOR_AUTH_COOKIE);
        if ($_cookie) {
            $_cookie = explode(',', $_cookie);
            if ( ! in_array($cookie, $_cookie)) {
                $_cookie[] = $cookie;
            }
            $_cookie = implode(',', $_cookie);
        } else {
            $_cookie = $cookie;
        }
        Mage::getSingleton('core/cookie')->set(self::TWO_FACTOR_AUTH_COOKIE, $_cookie, time() + 60*60*24*365*10);
    } */
    /**
     * Check whether the password was re-entered for sensitive actions.
     *
     * @return bool
     */
    public function isReAuthenticated()
    {
        return (bool) $this->adminSession->getData('reauthenticated_2fa', FALSE);
    } 
}
